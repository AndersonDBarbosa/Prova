package questao5.steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import questao5.pages.CheckoutPage;
import questao5.pages.HomePage;
import questao5.pages.ProductPage;
import questao5.pages.ShoppingCartPage;

public class Exercicios {
	WebDriver driver;
	JavascriptExecutor js;
	
	@Before
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@After
	public void after() {
		driver.quit();
	}

	@Dado("que estou no site informado")
	public void que_estou_no_site_informado() {
		driver.get("https://advantageonlineshopping.com/");
		driver.manage().window().maximize();
	}

	@Quando("clicar no botão ver ofertas")
	public void clicar_no_botão_ver_ofertas() throws InterruptedException {

		HomePage homePage = new HomePage(driver);
		homePage.apertaBotao();
	}

	@E("clicar no botão de oferta do produto")
	public void clicar_no_botão_de_oferta_do_produto() throws InterruptedException {
		HomePage homePage = new HomePage(driver);
		homePage.apertaBotaoOferta();
	}

	@Então("as especificações exibidas são corretas")
	public void as_especificações_exibidas_são_corretas() throws InterruptedException {
		ProductPage productPage = new ProductPage(driver);
		productPage.validaEspecificacoes();
	}

	@E("alterar cor do produto")
	public void alterar_cor_do_produto() {
		ProductPage productPage = new ProductPage(driver);
		productPage.alterarCor();
	}

	@E("clicar no botão adicionar ao carrinho")
	public void clicar_no_botão_adicionar_ao_carrinho() {
		ProductPage productPage = new ProductPage(driver);
		productPage.adicionarCarrinho();
	}

	@Então("o produto adicionado deve estar com a cor selecionada")
	public void o_produto_adicionado_deve_estar_com_a_cor_selecionada() throws InterruptedException {
		ProductPage productPage = new ProductPage(driver);
		productPage.validarPopupCarrinho();
	}

	@Quando("procurar pelo produto informado")
	public void procurar_pelo_produto_informado() throws InterruptedException {
		HomePage homePage = new HomePage(driver);
		homePage.procurarProdutoInformado();
	}

	@E("selecionar produto")
	public void selecionar_produto() throws InterruptedException {
		HomePage homePage = new HomePage(driver);
		homePage.clicarProduto();
	}

	@E("alterar quantidade do produto")
	public void alterar_quantidade_do_produto() throws InterruptedException {
		ProductPage productPage = new ProductPage(driver);
		productPage.aumentarQuantidade();
	}

	@E("clicar no botão do checkout")
	public void clicar_no_botão_do_checkout() throws InterruptedException {
		ProductPage productPage = new ProductPage(driver);
		productPage.clicarBotaoCheckout();
	}

	@Então("a soma dos preços dos produtos deve ser validada")
	public void a_soma_dos_preços_dos_produtos_deve_ser_validada() throws InterruptedException {
		CheckoutPage checkoutPage = new CheckoutPage(driver);
		checkoutPage.validaPrecoCheckout();
	}

	@E("clicar no carrinho")
	public void clicar_no_carrinho() throws InterruptedException {
		ProductPage productPage = new ProductPage(driver);
		productPage.clicarBotaoCarrinho();

	}

	@E("remover item do carrinho")
	public void remover_item_do_carrinho() throws InterruptedException {
		ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
		shoppingCartPage.removerItemCarrinho();
	}

	@Então("o item não deve estar no carrinho de compras")
	public void o_item_não_deve_estar_no_carrinho_de_compras() throws InterruptedException {
		ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
		shoppingCartPage.validarCarrinhoVazio();
	}
}
