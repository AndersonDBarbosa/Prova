package questao5.pages;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShoppingCartPage {

	WebDriver driver;

	public ShoppingCartPage(WebDriver driver) {
		this.driver = driver;
	}

	public void removerItemCarrinho() throws InterruptedException {
		driver.findElement(By.xpath("//a[@translate='REMOVE']")).click();
		TimeUnit.SECONDS.sleep(2);
	}
	
	public void validarCarrinhoVazio() throws InterruptedException {
		assertThat(driver.findElement(By.xpath("//label[@translate='Your_shopping_cart_is_empty']")).getText(),
				is("Your shopping cart is empty"));
		TimeUnit.SECONDS.sleep(1);
	}
}
