package questao5.pages;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class ProductPage {

	WebDriver driver;
	JavascriptExecutor js;
	final String BOTAO_OFERTA = "//a[contains(text(),'SPECIAL OFFER')]";

	public ProductPage(WebDriver driver) {
		this.driver = driver;
		js = (JavascriptExecutor) driver;
	}

	public void validaEspecificacoes() throws InterruptedException {

		js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//div[9]/label[2]")));
		TimeUnit.SECONDS.sleep(1);

		// Comparações
		assertThat(driver.findElement(By.xpath("//article[2]/div/label[2]")).getText(), is("Simplicity"));
		assertThat(driver.findElement(By.xpath("//div[2]/label[2]")).getText(),
				is("15.6-inch diagonal Full HD WLED-backlit Display (1920x1080) Touchscreen"));
		assertThat(driver.findElement(By.xpath("//div[3]/label[2]")).getText(), is("1920x1080"));
		assertThat(driver.findElement(By.xpath("//div[4]/label[2]")).getText(), is("15.6"));
		assertThat(driver.findElement(By.xpath("//div[5]/label[2]")).getText(), is("16GB DDR3 - 2 DIMM"));
		assertThat(driver.findElement(By.xpath("//div[6]/label[2]")).getText(), is("Windows 10"));
		assertThat(driver.findElement(By.xpath("//div[7]/label[2]")).getText(),
				is("AMD Quad-Core A10-8700P Processor + AMD Radeon(TM) R6 Graphics"));
		assertThat(driver.findElement(By.xpath("//div[8]/label[2]")).getText(), is("Yes"));
		assertThat(driver.findElement(By.xpath("//div[9]/label[2]")).getText(), is("5.51 lb"));
	}

	public void alterarCor() {
		driver.findElement(By.xpath("//span[@id='bunny'][@title='RED']")).click();
	}

	public void adicionarCarrinho() {
		driver.findElement(By.xpath("//button[@name='save_to_cart']")).click();
	}

	public void validarPopupCarrinho() throws InterruptedException {
		TimeUnit.SECONDS.sleep(2);
		assertThat(driver.findElement(By.xpath("//span[contains(text(),'RED')]")).getText(), is("RED"));
		TimeUnit.SECONDS.sleep(3);
	}

	public void aumentarQuantidade() throws InterruptedException {
		driver.findElement(By.xpath("//div[@class='plus']")).click();
		TimeUnit.SECONDS.sleep(1);
	}

	public void clicarBotaoCheckout() throws InterruptedException {
		driver.findElement(By.xpath("//button[@id='checkOutPopUp']")).click();
		TimeUnit.SECONDS.sleep(2);

	}

	public void clicarBotaoCarrinho() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='shoppingCartLink']")).click();
		TimeUnit.SECONDS.sleep(2);
	}

}
