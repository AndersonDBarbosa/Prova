package questao5.pages;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
	WebDriver driver;
	JavascriptExecutor js;
	final String BOTAO_OFERTA = "//a[contains(text(),'SPECIAL OFFER')]";

	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
		js = (JavascriptExecutor) driver;
	}

	public void validaPrecoCheckout() throws InterruptedException {

	//	js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//div[9]/label[2]")));
		TimeUnit.SECONDS.sleep(3);
		assertThat(driver.findElement(By.cssSelector(".totalValue")).getText(), is("$899.98"));
		
	}
}
