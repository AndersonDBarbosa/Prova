package questao5.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	
	WebDriver driver;
	JavascriptExecutor js;
	final String BOTAO_OFERTA = "//a[contains(text(),'SPECIAL OFFER')]";
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void apertaBotao() throws InterruptedException {
		WebElement element = new WebDriverWait(driver, 5)
				.until(ExpectedConditions.elementToBeClickable(By.xpath(BOTAO_OFERTA)));
		TimeUnit.SECONDS.sleep(1);
		element.click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	public void apertaBotaoOferta() throws InterruptedException {
		driver.findElement(By.id("see_offer_btn")).click();
		TimeUnit.SECONDS.sleep(1);
	}
	
	public void procurarProdutoInformado() throws InterruptedException {
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("//div[@id='searchSection']")).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(By.xpath("//input[@id='autoComplete']")).sendKeys("15Z TOUCH LAPTOP");
	}
	
	public void clicarProduto() throws InterruptedException {
		TimeUnit.SECONDS.sleep(4);
		driver.findElement(By.xpath("//a[2]/p")).click();
		TimeUnit.SECONDS.sleep(3);
	}
}
