package exerciciosProva;

public class Questao1a3 {

	public static void main(String[] args) {

		/*
		 * Questão 1 - Como sabemos que testar uma aplicação requer conhecimento de
		 * técnicas para ser possível efetuar uma maior cobertura e qualidade nas
		 * features que estão sendo entregues. Considerando isso, cite as técnicas teste
		 * de software existentes, comentando também sobre suas diferenças e
		 * aplicabilidade.
		 * 
		 * Resposta: Os testes de caixa branca são testes focados no código fonte da
		 * funcionalidade, normalmente quando os testes unitários são realizados,
		 * garantindo que cada parte do código esteja integra e nos padrões de
		 * desenvolvimento. Já os testes de caixa preta são os testes funcionais, que
		 * visam testar a aplicação em si, verificando botões, layouts, funcionalidades,
		 * se tudo está de acordo com o planejado.
		 * 
		 * Questão 2 - Considerando que já sabemos as técnicas de teste de software
		 * existentes, comente sobre os tipos de testes de software existentes e suas
		 * finalidades.
		 * 
		 * Resposta: Os testes regressivos são realizados após a implantação de uma nova
		 * funcionalidade, validando se o que foi alterado não quebrou o que já
		 * funcionava anteriormente, geralmente realizado no fim da homologação. Os
		 * testes de integração são realizados após a entrega de todas as partes que
		 * fazem parte do fluxo desenvolvido, após ambas as partes concluírem sua
		 * homologação, os testes integrados devem ser iniciados, garantindo que as
		 * partes desenvolvidas iniciem um fluxo e concluem no fim, atendendo o seu
		 * propósito. Os testes funcionais podem ser tanto manuais quanto automatizados,
		 * devem garantir que o fluxo da funcionalidade desenvolvida esteja de acordo
		 * com protótipos desenhados e requisitos definidos pelo dono do produto, a
		 * partir do início do desenvolvimento da aplicação, os testes funcionais devem
		 * ser realizados.
		 * 
		 * Questão 3 - Uma das principais características de um Engenheiro de Qualidade
		 * é a técnica de visualizar comportamentos existentes dentro de fluxos ou
		 * estórias de usuário e transcreve-los dessa forma. Essa técnica permite que
		 * uma documentação seja criada logo na fase de planejamento do projeto, dessa
		 * forma servirá como orientação tanto para o Desenvolvedor, quanto para o
		 * Engenheiro de Qualidade. Considerando isso, cite qual é a técnica utilizada
		 * para esse tipo de escrita e os ciclos necessários para seu desenvolvimento.
		 * 
		 * Resposta: Normalmente após a criação das estórias de usuário, quando são
		 * passadas para o Engenheiro de Qualidade, os BDDs são criados, podem usar a
		 * técnica Gherkin ou não para a criação, a utilização da técnica Gherkin no BDD
		 * auxilia a criação dos testes automatizados e é um padrão que se utiliza
		 * quando se automatizam os testes. Após os cenários forem criados, os testes
		 * são executados e ao encontrar defeitos, os bugs são abertos para o
		 * desenvolvedor corrigir, utilizando testes automatizados agiliza bastante a
		 * parte da regressão da funcionalidade e dos testes em geral da mesma.
		 */
	}

}
